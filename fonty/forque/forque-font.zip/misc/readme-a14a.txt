Free font by Tup Wanders
https://wanders.work

This Font Software is licensed under the SIL Open Font License, Version 1.1.

If you add to the font, please send me a copy! If you've made fun stuff with the font that you would like to show me, please send me that as well. I like that.

Have fun,
Tuppus
tup@wanders.work

If this font suddenly makes you feel like spending huge amounts of money, please do so by going to Paypal and transferring your fortune to tup@wanders.work
And if this font suddenly makes feel like spending small or moderately large amounts of money, you can do that via Paypal as well. It pays the software I use.

More fonts here:
http://www.dafont.com/tup-wanders.d2245
or here
http://www.fontspace.com/tup-wanders  
or here
https://wanders.work